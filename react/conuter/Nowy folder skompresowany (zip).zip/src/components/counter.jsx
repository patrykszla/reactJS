import React from 'react';
/* import CounterFn from './counterFn';   */  
import './counter.css';
import ButtonsPanel from './buttonsPanel';

class Counter extends React.Component { //dziedziczy po komponencie reactowym
         
    //      state = {
    //          counterValue: 0,   
    //  }

    constructor(props) {
        super(props);
        let initValue =0;
        if( ! isNaN(this.props.initValue) ) {
            initValue = parseInt(this.props.initValue);
        }
        this.state = {
            counterValue: initValue, // bo obiekt 
        }
    }

    /*  changeValue = () => {
    
             this.setState((prevState) => {
                    return({
                        counterValue: prevState.counterValue +1,
                         })
                        }
                    }
                 
         */


    changeValue = () => {
        this.setState({
            counterValue: this.state.counterValue + 1,
        })
     }

     resetCounter = (resetCounter) => {
         let initValue = 0

         if(!resetCounter) {
             if ( ! isNaN(this.props.initValue)) {    //jesli jest not a number zwraca nam true
                initValue = parseInt(this.props.initValue);
             } 
         }
         
         this.setState({
             counterValue: initValue
         })
     }

    render() {
        return(
            <div className="counter">
                Licznik:
                <span className="value">{this.state.counterValue}</span>
                {/* <button onClick={this.changeValue}>Add 1</button>   */}      
                <ButtonsPanel changeValue={this.changeValue} resetCounterValue={this.resetCounter}/>
            </div>
             
        )
    }
}

export default Counter;