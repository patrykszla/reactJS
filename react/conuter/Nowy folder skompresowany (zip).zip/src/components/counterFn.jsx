import React from 'react';



const CounterFn = (props) => {
    const nazwa ='Funkcyjny'
    return(
    <div>Licznik {props.nazwa}</div>   //parametr  i nazwa propsu
    )
}

export default CounterFn;